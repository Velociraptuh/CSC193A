/*
 * Starter file 
 */
//console.log("Loaded");
(function() {
  "use strict";

  /**
   * The starting point in our program, setting up a listener
   * for the "load" event on the window, signalling the HTML DOM has been constructed
   * on the page. When this event occurs, the attached function (init) will be called.
   */
  window.addEventListener("load", init);


  /**
   * TODO: Initialize function
   */
  function init() {
    // Note: In this function, we usually want to set up our event handlers
    // for UI elements on the page.
    const encEl = document.getElementById("encrypt-it");
    var textarea = document.getElementById("input-text");
    //var str = textarea.value;
    //console.log(str);
    encEl.addEventListener("click", shiftCypher);
    const resEl = document.getElementById("reset");
    resEl.addEventListener("click", handleReset);
    
  }


  // Add any other functions in this area (you should not implement your
  // entire program in the init function, for similar reasons that
  // you shouldn't write an entire Java program in the main method).
  /**
   * TODO handle click
   */
  function shiftCypher(){
    var textarea = document.getElementById("input-text");
    var text = textarea.value;
    console.log("Button Clicked!");
    console.log(text);
    let result = "";
    for(let i = 0; i < text.length; i++){
      if(text[i] < 'a' || text[i] > 'z'){
        result += text[i];
      }else if(text[i] == 'z'){
        result += 'a';
      }else{
        let letter = text.charCodeAt(i);
        let resultLetter = String.fromCharCode(letter + 1);
        result += resultLetter;
      }
      }
      document.getElementById("result").innerText = result;
      var textar = document.getElementById("result");
      textar.value = result;
      console.log(result);
      return result;
    }
  

  function handleReset(){
    var textarea = document.getElementById("input-text");
    textarea.value="";
  }

})();
